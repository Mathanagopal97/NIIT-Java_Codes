package com.nik;


public class Person
{
private int id;

private int age;
private String fname;
private String lname;
public int getId()
{
	return id;
}
public void setId(int id)
{
	this.id = id;
}
public int getAge()
{
	return age;
}
public void setAge(int age)
{
	this.age = age;
}
public String getFname()
{
	return fname;
}
public void setFname(String fname)
{
	this.fname = fname;
}
public String getLname()
{
	return lname;
}
public void setLname(String lname)
{
	this.lname = lname;
}



}

