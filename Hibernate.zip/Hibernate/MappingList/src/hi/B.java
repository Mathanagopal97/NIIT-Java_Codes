package hi;
public class B
{
	
}