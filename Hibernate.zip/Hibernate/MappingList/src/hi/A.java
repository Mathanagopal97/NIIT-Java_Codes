package hi;

class A
{
public static void main(String[] args)
{
	final int i=90;
	class B
	{
		void test()
		{
			System.out.println(i);
		}
	}
	
}
}
	